# Helper (private) — Mindustry PC
Установка: положи `helper-private.zip` (zip с mod.json и scripts/) в папку модов:
%AppData%/Mindustry/mods (Windows) → Mods → Reload. Меню: F6 / кнопка Helper.
Функции «локально» работают в синглплеере/на своём сервере.
