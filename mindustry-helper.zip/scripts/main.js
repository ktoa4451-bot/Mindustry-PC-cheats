// Helper (private) — клиентский JS-мод для Mindustry (PC). Меню: F6 или кнопка "Helper" в HUD.
const F = {
  esp: true,          // линии и HP-бары врагов
  ranges: true,       // радиус вражеских турелей
  autoAim: false,     // автонаведение/стрельба по ближайшему врагу
  autoMine: false,    // автодобыча меди/свинца
  autoRebuild: false, // автовосстановление разрушенных блоков
  god: false,         // неуязвимость (только локально/в синглплеере)
  fastBuild: false,   // x10 скорость стройки (локально)
  infinite: false,    // бесконечные ресурсы (локально)
  zoom: true          // расширенный зум
};

let dlg = null;

function build() {
  dlg = new BaseDialog("Helper");
  const names = {
    esp: "ESP врагов", ranges: "Радиус вражеских турелей", autoAim: "Автонаведение",
    autoMine: "Автодобыча", autoRebuild: "Автовосстановление", god: "Неуязвимость (локально)",
    fastBuild: "Быстрая стройка (локально)", infinite: "Бесконечные ресурсы (локально)", zoom: "Расширенный зум"
  };
  Object.keys(names).forEach(k => {
    dlg.cont.check(names[k], F[k], boolf(v => { F[k] = v; apply(); })).left().row();
  });
  dlg.cont.button("Пропустить волну", run(() => { try { Vars.logic.runWave(); } catch (e) {} })).size(240, 50).row();
  dlg.addCloseButton();
}

function apply() {
  try {
    Vars.state.rules.buildSpeedMultiplier = F.fastBuild ? 10 : 1;
    Vars.state.rules.infiniteResources = F.infinite;
    if (F.zoom) { Vars.renderer.minZoom = 0.3; Vars.renderer.maxZoom = 12; }
    else { Vars.renderer.minZoom = 1.5; Vars.renderer.maxZoom = 6; }
  } catch (e) {}
}

Events.on(ClientLoadEvent, e => {
  build();
  Vars.ui.hudGroup.fill(cons(t => {
    t.bottom().left().marginBottom(120);
    t.button("Helper", run(() => dlg.show())).size(110, 44);
  }));
  apply();
});

Events.run(Trigger.update, () => {
  if (!Vars.state.isGame() || Vars.player == null) return;
  if (Core.input.keyTap(KeyCode.f6) && dlg != null) dlg.show();
  const u = Vars.player.unit();
  if (u == null || u.dead) return;

  if (F.god) u.health = u.maxHealth;

  if (F.autoAim && u.type.canAttack) {
    const t = Units.closestTarget(u.team, u.x, u.y, u.range(), e => e.checkTarget(true, true), b => true);
    if (t != null) { u.aim(t.getX(), t.getY()); Vars.player.shooting = true; }
    else Vars.player.shooting = false;
  }

  if (F.autoMine && u.type.mineSpeed > 0 && u.mineTile == null) {
    const core = u.closestCore();
    if (core != null) {
      const item = core.items.get(Items.copper) <= core.items.get(Items.lead) ? Items.copper : Items.lead;
      const tile = Vars.indexer.findClosestOre(u, item);
      if (tile != null && u.validMine(tile)) u.mineTile = tile;
    }
  }

  if (F.autoRebuild && u.type.buildSpeed > 0 && !u.activelyBuilding()) {
    const plans = u.team.data().plans;
    if (plans.size > 0) {
      const p = plans.first();
      u.addBuild(new BuildPlan(p.x, p.y, p.rotation, Vars.content.block(p.block), p.config));
    }
  }
});

Events.run(Trigger.draw, () => {
  if (!Vars.state.isGame() || Vars.player == null) return;
  const me = Vars.player.unit();
  Draw.z(Layer.overlayUI);

  if (F.esp && me != null) {
    Groups.unit.each(e => {
      if (e.team == Vars.player.team() || e.dead) return;
      Lines.stroke(1);
      Draw.color(Color.red, 0.5);
      Lines.line(me.x, me.y, e.x, e.y);
      const w = e.hitSize * 1.2, hp = Mathf.clamp(e.health / e.maxHealth);
      Draw.color(Color.black, 0.7);
      Fill.rect(e.x, e.y + e.hitSize, w, 2.5);
      Draw.color(Color.red);
      Fill.rect(e.x - w * (1 - hp) / 2, e.y + e.hitSize, w * hp, 2.5);
    });
  }

  if (F.ranges) {
    Groups.build.each(b => {
      if (b.team == Vars.player.team() || !(b.block instanceof Turret)) return;
      Lines.stroke(1);
      Draw.color(Color.orange, 0.6);
      Lines.circle(b.x, b.y, b.block.range);
    });
  }
  Draw.reset();
});
