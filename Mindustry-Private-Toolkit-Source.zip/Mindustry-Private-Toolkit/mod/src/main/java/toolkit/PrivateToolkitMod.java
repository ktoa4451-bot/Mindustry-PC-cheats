package toolkit;

import mindustry.mod.Mod;

/**
 * Minimal entry point. The mod is intentionally conservative:
 * no process injection, memory editing, networking, or server interaction.
 */
public final class PrivateToolkitMod extends Mod {
    @Override
    public void loadContent() {
        // The first build verifies that the mod loads in Mindustry.
        // Local single-player features can be added here using the supported Mindustry API.
    }
}
