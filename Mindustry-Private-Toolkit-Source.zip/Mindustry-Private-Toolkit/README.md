# Mindustry Private Toolkit

Локальный проект для Mindustry v8 Build 160.x. Предназначен только для одиночной игры и локальных миров.

## Состав
- `mod/` — Java-мод, который загружается самой Mindustry.
- `launcher/` — Windows x64 лаунчер на .NET Framework 4.8.
- `.github/workflows/build.yml` — сборка JAR и EXE через GitHub Actions.

## Что делает первая заготовка
- EXE позволяет выбрать `Mindustry.exe`, установить JAR в `%APPDATA%\Mindustry\mods` и запустить игру.
- JAR — минимальный загрузочный мод-заготовка. Игровые функции добавляются через официальный API Mindustry, без внедрения в процесс игры.

## Сборка на GitHub
1. Создай пустой репозиторий на GitHub.
2. Загрузи в него всё содержимое этой папки (именно содержимое, а не вложенную папку).
3. Открой вкладку **Actions** и запусти workflow **Build Private Toolkit** через **Run workflow**.
4. После завершения открой запуск workflow и скачай artifact `Mindustry-Private-Toolkit-Windows-x64`.

В artifact будут:
- `PrivateToolkit.exe`
- `PrivateToolkit.jar`
- `README.txt`

## Установка
1. Распакуй artifact.
2. Запусти `PrivateToolkit.exe`.
3. Нажми `Browse`, выбери `Mindustry.exe`.
4. Нажми `Install mod`.
5. Запусти Mindustry из лаунчера или обычным способом.

## Требования и совместимость
- Mindustry v8 Build 160.x.
- Windows 7 SP1 x64 и .NET Framework 4.8 для лаунчера.
- Для запуска самой игры нужна совместимая с ней Java Runtime / сборка игры. Совместимость Mindustry Build 160.7 с Windows 7 не гарантируется.
- JAR собирается в GitHub Actions с Java 17; локально JDK устанавливать не требуется.

## Важно
Это начальная безопасная заготовка, а не готовый набор чит-функций. Она не меняет память процесса, не обходит защиту и не предназначена для сетевой игры. Не устанавливай неизвестные JAR-файлы из непроверенных источников.
