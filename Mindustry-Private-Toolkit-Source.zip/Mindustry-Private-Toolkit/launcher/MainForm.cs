using System;
using System.Diagnostics;
using System.IO;
using System.Drawing;
using System.Windows.Forms;

namespace PrivateToolkit
{
    public sealed class MainForm : Form
    {
        private readonly TextBox gamePath = new TextBox();
        private readonly Label status = new Label();

        public MainForm()
        {
            Text = "Mindustry Private Toolkit";
            ClientSize = new Size(560, 245);
            MinimumSize = new Size(576, 284);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.FromArgb(22, 23, 31);
            ForeColor = Color.White;

            var heading = new Label {
                Text = "MINDUSTRY  /  PRIVATE TOOLKIT",
                Left = 22, Top = 20, Width = 510, Height = 30,
                ForeColor = Color.FromArgb(177, 135, 255),
                Font = new Font("Segoe UI", 13, FontStyle.Bold)
            };
            Controls.Add(heading);

            var hint = new Label {
                Text = "Выбери исполняемый файл Mindustry, затем установи локальный мод.",
                Left = 24, Top = 66, Width = 510, Height = 36,
                ForeColor = Color.Gainsboro
            };
            Controls.Add(hint);

            gamePath.SetBounds(24, 112, 390, 27);
            gamePath.BackColor = Color.FromArgb(38, 40, 52);
            gamePath.ForeColor = Color.White;
            gamePath.BorderStyle = BorderStyle.FixedSingle;
            Controls.Add(gamePath);

            var browse = MakeButton("Browse", 424, 110, 108);
            browse.Click += (s, e) => BrowseGame();
            Controls.Add(browse);

            var install = MakeButton("Install mod", 24, 155, 150);
            install.Click += (s, e) => InstallMod();
            Controls.Add(install);

            var launch = MakeButton("Launch Mindustry", 184, 155, 170);
            launch.Click += (s, e) => LaunchGame();
            Controls.Add(launch);

            status.SetBounds(24, 202, 510, 28);
            status.ForeColor = Color.LightGray;
            status.Text = "Готово. Мод предназначен для одиночной игры.";
            Controls.Add(status);
        }

        private Button MakeButton(string text, int x, int y, int width)
        {
            return new Button {
                Text = text, Left = x, Top = y, Width = width, Height = 34,
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(91, 61, 153),
                ForeColor = Color.White
            };
        }

        private void BrowseGame()
        {
            using (var dialog = new OpenFileDialog())
            {
                dialog.Title = "Выбери Mindustry.exe";
                dialog.Filter = "Mindustry executable|Mindustry.exe|Executable files|*.exe";
                if (dialog.ShowDialog(this) == DialogResult.OK)
                    gamePath.Text = dialog.FileName;
            }
        }

        private string GetModSource()
        {
            string besideExe = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "PrivateToolkit.jar");
            if (File.Exists(besideExe)) return besideExe;

            string besideLauncher = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "mods", "PrivateToolkit.jar");
            if (File.Exists(besideLauncher)) return besideLauncher;

            return null;
        }

        private void InstallMod()
        {
            string source = GetModSource();
            if (source == null)
            {
                status.Text = "Не найден PrivateToolkit.jar рядом с EXE.";
                return;
            }

            try
            {
                string mods = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                    "Mindustry", "mods");
                Directory.CreateDirectory(mods);
                File.Copy(source, Path.Combine(mods, "PrivateToolkit.jar"), true);
                status.Text = "Мод установлен в " + mods;
            }
            catch (Exception ex)
            {
                status.Text = "Ошибка установки: " + ex.Message;
            }
        }

        private void LaunchGame()
        {
            string path = gamePath.Text.Trim().Trim('"');
            if (!File.Exists(path))
            {
                status.Text = "Сначала выбери существующий Mindustry.exe.";
                return;
            }

            try
            {
                Process.Start(new ProcessStartInfo {
                    FileName = path,
                    WorkingDirectory = Path.GetDirectoryName(path),
                    UseShellExecute = true
                });
                status.Text = "Mindustry запущена.";
            }
            catch (Exception ex)
            {
                status.Text = "Ошибка запуска: " + ex.Message;
            }
        }
    }
}
